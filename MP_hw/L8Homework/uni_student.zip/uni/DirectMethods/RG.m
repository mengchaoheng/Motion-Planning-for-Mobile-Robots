%contact: Lai Shupeng
%email: shupenglai@gmail.com
function f = RG(lb,ub)
f = lb + (ub - lb)*rand;
end